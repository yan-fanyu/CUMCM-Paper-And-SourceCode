%% 数据预处理程序3 大极差模型的确立和预测能力
clc
clear
load("fujian.mat")
%% 表格数据说明
% 第二次评审 评审极差和复议后极差[4,5]
ind0=[4,5];
%            shuju21 240条二审
%            shuju22 1500条二审
% 第一次评审 专家编码列数[6,9,12,15,18]
%            原始分列数[7,10,13,16,19]
%            标准分列数[8,11,14,17,20]
ind1=[6,9,12,15,18];ind2=[7,10,13,16,19];ind3=[8,11,14,17,20];
% 第二次评审 专家编码列数[24,28,32]
%            原始分列数[25,29,33]
%            标准分列数[26,30,34]
%            复议分列数[27,31,35]
ind4=[24,28,32];ind5=[25,29,33];ind6=[26,30,34];ind7=[27,31,35];
%% 统计附件2.1极差和均值变化  这里是复议前后，复议前e(i,1)，复议后e(i,2) s->score也是同理
t1=0;t2=0;
for i=1:240
    e1(i,1)=shuju21{i,4};
    s1(i,1)=sum(shuju21{i,ind6});
    d1(i,1)=std(shuju21{i,ind6});
    if shuju21{i,5}==0
        e1(i,2)=e1(i,1);
        s1(i,2)=s1(i,1);
        d1(i,2)=d1(i,1);
        t1=t1+1;
    else
        e1(i,2)=shuju21{i,5};
        s1(i,2)=sum(shuju21{i,ind7});
        d1(i,2)=sum(shuju21{i,ind7});
    end
end
for i=1:1500
    e2(i,1)=shuju22{i,4};
    s2(i,1)=sum(shuju22{i,ind6});
    d2(i,1)=sum(shuju22{i,ind6});
    if shuju22{i,5}==0
        e2(i,2)=e2(i,1);
        s2(i,2)=s2(i,1);
        d2(i,2)=d2(i,1);
        t2=t2+1;
    else
        e2(i,2)=shuju22{i,5};
        s2(i,2)=sum(shuju22{i,ind7});
        d2(i,2)=sum(shuju22{i,ind7});
    end
end
data=shuju22{1:1500,ind6};
%% 给出一些标识，用于调取索引
%三分类散点图
% index1=(s2(:,1)>s2(:,2)); %复议分低于标准分
% index2=1:1500;
% scatter3(e2(index2,1),e2(index2,1)-e2(index2,2),s2(index2,2)-s2(index2,1),'red','*')
% hold on
% index2=(abs(abs(s2(:,1)-s2(:,2))-(e2(:,1)-e2(:,2)))<=0.001);
% scatter3(e2(index2,1),e2(index2,1)-e2(index2,2),s2(index2,2)-s2(index2,1),'green','*')
% index2=(abs(s2(:,1)-s2(:,2))-(e2(:,1)-e2(:,2))<=-0.001);
% scatter3(e2(index2,1),e2(index2,1)-e2(index2,2),s2(index2,2)-s2(index2,1),'blue','*')
% xlabel('初始极差')
% ylabel('初始极差-复议后极差')
% zlabel('复议前后分数差')
% title('附件22')
% hold off
% grid on

%% 给出一些标识，用于调取索引
%三分类散点图
% index=(s2(:,1)>s2(:,2)); %复议分低于标准分
% index2=1:1500;
% scatter3(e2(index2,1),e2(index2,1)-e2(index2,2),s2(index2,2)-s2(index2,1),'red','*')
% hold on
% index2=(abs(abs(s2(:,1)-s2(:,2))-(e2(:,1)-e2(:,2)))<=0.001);
% scatter3(e2(index2,1),e2(index2,1)-e2(index2,2),s2(index2,2)-s2(index2,1),'green','*')
% index2=(abs(s2(:,1)-s2(:,2))-(e2(:,1)-e2(:,2))<=-0.001);
% scatter3(e2(index2,1),e2(index2,1)-e2(index2,2),s2(index2,2)-s2(index2,1),'blue','*')
% xlabel('初始极差')
% ylabel('初始极差-复议后极差')
% zlabel('复议前后分数差')
% title('附件22')
% hold off
% grid on

%% 乱序版图片
% index1=(abs(abs(s2(:,1)-s2(:,2))-(e2(:,1)-e2(:,2)))>0.001);
% index2=(abs(abs(s2(:,1)-s2(:,2))-(e2(:,1)-e2(:,2)))<=0.001);
% index3=(abs(s2(:,1)-s2(:,2))-(e2(:,1)-e2(:,2))<=-0.001);
% scatter3(data(index1,1),data(index1,2),data(index1,3),'red','*')
% hold on
% index2=(abs(abs(s2(:,1)-s2(:,2))-(e2(:,1)-e2(:,2)))<=0.001);
% scatter3(data(index2,1),data(index2,2),data(index2,3),'green','*')
% index2=(abs(s2(:,1)-s2(:,2))-(e2(:,1)-e2(:,2))<=-0.001);
% scatter3(data(index3,1),data(index3,2),data(index3,3),'blue','*')
% title('附件22')
% hold off
% grid on

data=sort(data,2); %排序
%% 多分类可视化——分成极差与分数变化关联性的三类
% index1=(abs(abs(s2(:,1)-s2(:,2))-(e2(:,1)-e2(:,2)))>0.001);
% index2=(abs(abs(s2(:,1)-s2(:,2))-(e2(:,1)-e2(:,2)))<=0.001);
% index3=(abs(s2(:,1)-s2(:,2))-(e2(:,1)-e2(:,2))<=-0.001);
% scatter3(data(index1,1),data(index1,2),data(index1,3),'red','*')
% hold on
% index2=(abs(abs(s2(:,1)-s2(:,2))-(e2(:,1)-e2(:,2)))<=0.001);
% scatter3(data(index2,1),data(index2,2),data(index2,3),'green','*')
% index2=(abs(s2(:,1)-s2(:,2))-(e2(:,1)-e2(:,2))<=-0.001);
% scatter3(data(index3,1),data(index3,2),data(index3,3),'blue','*')
% title('附件22')
% hold off
% grid on

%% 多分类可视化
% hold on
% for i=[20:-10:-20]
%     index2=(s2(:,2)-s2(:,1)<=i);
%     scatter3(data(index2,1),data(index2,2),data(index2,3),'*')
% end
% hold off
% grid on

%% 画出分布图象
% hist_del0(s2(:,2)-s2(:,1))

%% 数据特征分析 画出极差较大的两个分类（正向和负向）
hold on
index2=(s2(:,2)-s2(:,1)<-2);
scatter3(data(index2,1),data(index2,2),data(index2,3),'green','*')
index2=(s2(:,2)-s2(:,1)>2);
scatter3(data(index2,1),data(index2,2),data(index2,3),'red','*')
% index2=(s2(:,2)-s2(:,1)<-10);
% scatter3(data(index2,1),data(index2,2),data(index2,3),'blue','*')
% index2=(s2(:,2)-s2(:,1)>10);
% scatter3(data(index2,1),data(index2,2),data(index2,3),'yellow','*')
hold off
grid on


function []=hist_del0(data)
d=data(abs(data)>2);
histogram(d)
histfit(d)
end
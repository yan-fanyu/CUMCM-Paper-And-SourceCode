%% 数据预处理程序4 大极差模型的确立和预测能力2 SVM支持向量机
clc
clear
load("fujian.mat")
%% 表格数据说明
% 第二次评审 评审极差和复议后极差[4,5]
ind0=[4,5];
%            shuju21 240条二审
%            shuju22 1500条二审
% 第一次评审 专家编码列数[6,9,12,15,18]
%            原始分列数[7,10,13,16,19]
%            标准分列数[8,11,14,17,20]
ind1=[6,9,12,15,18];ind2=[7,10,13,16,19];ind3=[8,11,14,17,20];
% 第二次评审 专家编码列数[24,28,32]
%            原始分列数[25,29,33]
%            标准分列数[26,30,34]
%            复议分列数[27,31,35]
ind4=[24,28,32];ind5=[25,29,33];ind6=[26,30,34];ind7=[27,31,35];
data=shuju22{1:1500,ind6};data=sort(data,2); 
%% 数据预处理
for i=1:1500
    e2(i,1)=shuju22{i,4};
    s2(i,1)=sum(shuju22{i,ind6});
    d2(i,1)=sum(shuju22{i,ind6});
    if shuju22{i,5}==0
        e2(i,2)=e2(i,1);
        s2(i,2)=s2(i,1);
        d2(i,2)=d2(i,1);
    else
        e2(i,2)=shuju22{i,5};
        s2(i,2)=sum(shuju22{i,ind7});
        d2(i,2)=sum(shuju22{i,ind7});
    end
end
index1=(s2(:,2)-s2(:,1)<-2);
index2=(s2(:,2)-s2(:,1)>2);
index3=(abs(s2(:,2)-s2(:,1))<2);
train_data1=data(index1,:);
train_data2=data(index2,:);
train_data3=data(index3,:);
train_data1=[train_data1,ones(length(train_data1(:,1)),1)];
train_data2=[train_data2,2*ones(length(train_data2(:,1)),1)];
train_data3=[train_data3,3*ones(length(train_data3(:,1)),1)];
train=[train_data1;train_data2;train_data3];

%% KNN分类算法
K_Max=20;
acc_avg_history=[];
for k=1:K_Max
    %K交叉验证
    N=5;%K交叉验证的份数
    rawrank=randperm(size(train,1));%打乱顺序
    rand_train=train(rawrank,:);
    cell_train=mat2cell(rand_train,1500/N*ones(1,N));%分为N份
    for n=1:N
        cell_train=circshift(cell_train,1);%移位一次
        train_set=cell2mat(cell_train(1:N-1));%取N-1份做训练集
        test_set=cell_train{N};%取N份做测试集
        pre_label=knn(test_set(:,1:4),train_set,k);%KNN预测
        accuracy(n)=sum(pre_label==test_set(:,4))/(1500/N);%求正确率
    end
    acc_average=mean(accuracy);%求平均正确率
    acc_avg_history=[acc_avg_history acc_average];%保存不同K值下的正确率
end
plot(acc_avg_history);xlabel('K');ylabel('准确率');title('交叉验证(N=5)选择K值')
function out=knn(test_set,train_set,K)
    [n ,~]=size(test_set);
    [m,~]=size(train_set);
    for i=1:n
        for j=1:m
            %求距离
            distance(j)=sqrt(sum((test_set(i,1:3)-train_set(j,1:3)).^2));
        end
        [~,index]=sort(distance,'ascend');
        label=train_set(index,4);%按照距离大小排序
        out(i)=mode(label(1:K));%取前K个标签里出现次数最多的那个标签
    end   
    out=out';
end

%% q3_1无法运行的看过来！！能运行的不要看
% 主要是为了解决range函数不能运行的问题
load("q31data.mat")
%% 附件21作图1
% subplot(1,2,1)
% scatter(s1(:,1),s1(:,2),'red','*')
% xlabel('第一次均值')
% ylabel('第二次均值')
% title('附件21')
% grid on
% subplot(1,2,2)
% scatter(e1(:,1),e1(:,2),'red','*')
% xlabel('第一次极差')
% ylabel('第二次极差')
% title('附件21')
% grid on

%% 附件22作图2
% subplot(1,2,1)
% scatter(s2(:,1),s2(:,2),'red','*')
% xlabel('第一次均值')
% ylabel('第二次均值')
% title('附件22')
% grid on
% subplot(1,2,2)
% scatter(e2(:,1),e2(:,2),'red','*')
% xlabel('第一次极差')
% ylabel('第二次极差')
% title('附件22')
% grid on

% %% 附件21作图3
% subplot(1,2,1)
% index=s1(:,2)>s1(:,1);
% scatter(e1(:,1),e1(:,2),'red','*')
% hold on
% scatter(e1(index,1),e1(index,2),'green','*')
% xlabel('第一次极差')
% ylabel('第二次极差')
% title('附件21')
% hold off
% grid on
% %% 附件22作图3
% subplot(1,2,2)
% index=s2(:,2)>s2(:,1);
% scatter(e2(:,1),e2(:,2),'red','*')
% hold on
% scatter(e2(index,1),e2(index,2),'green','*')
% xlabel('第一次极差')
% ylabel('第二次极差')
% title('附件22')
% hold off
% grid on

%% 附件21作图4
% subplot(1,2,1)
% index=1:70;
% scatter(e1(:,1),e1(:,2),'red','*')
% hold on
% scatter(e1(index,1),e1(index,2),'green','*')
% xlabel('第一次极差')
% ylabel('第二次极差')
% title('附件21')
% hold off
% grid on
%% 附件22作图4
%subplot(1,2,2)
index=1:200;pindex=[201:1500];
scatter(e2(:,1),e2(:,2),'red','*')
hold on
plot(mean(e2(pindex,1))*ones(1,2),[0,60])
scatter(e2(index,1),e2(index,2),'green','*')
plot(mean(e2(index,1))*ones(1,2),[0,60])
xlabel('第一次极差')
ylabel('第二次极差')
title('附件22')
hold off
grid on

%% 附件21作图5
% subplot(2,2,1)
% hist_del0(s1(:,1))
% xlabel('第一次均值')
% title('附件21')
% subplot(2,2,2)
% hist_del0(s1(:,2))
% xlabel('第二次均值')
% title('附件21')
% subplot(2,2,3)
% hist_del0(e1(:,1))
% xlabel('第一次极差')
% title('附件21')
% subplot(2,2,4)
% hist_del0(e1(:,2))
% xlabel('第二次极差')
% title('附件21')


%% 附件22作图5
% subplot(2,2,1)
% hist_del0(s2(:,1))
% xlabel('第一次均值')
% title('附件22')
% subplot(2,2,2)
% hist_del0(s2(:,2))
% xlabel('第二次均值')
% title('附件22')
% subplot(2,2,3)
% hist_del0(e2(:,1))
% xlabel('第一次极差')
% title('附件22')
% subplot(2,2,4)
% hist_del0(e2(:,2))
% xlabel('第二次极差')
% title('附件22')


function []=hist_del0(data)
d=data(data~=0);
histogram(d)
histfit(d)
end

function m=mean_del0(data)
d=data(data~=0);
m=mean(d);
end

function m=std_del0(data)
d=data(data~=0);
m=std(d);
end
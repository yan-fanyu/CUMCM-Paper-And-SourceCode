%% 数据预处理程序2 大极差模型
clc
clear
load("fujian.mat")
%% 表格数据说明
% 第二次评审 评审极差和复议后极差[4,5]
ind0=[4,5];
%            shuju21 240条二审
%            shuju22 1500条二审
% 第一次评审 专家编码列数[6,9,12,15,18]
%            原始分列数[7,10,13,16,19]
%            标准分列数[8,11,14,17,20]
ind1=[6,9,12,15,18];ind2=[7,10,13,16,19];ind3=[8,11,14,17,20];
% 第二次评审 专家编码列数[24,28,32]
%            原始分列数[25,29,33]
%            标准分列数[26,30,34]
%            复议分列数[27,31,35]
ind4=[24,28,32];ind5=[25,29,33];ind6=[26,30,34];ind7=[27,31,35];
%% 统计附件2.1极差和均值变化  这里是复议前后，复议前e(i,1)，复议后e(i,2) s->score也是同理
t1=0;t2=0;
for i=1:240
    e1(i,1)=shuju21{i,4};
    s1(i,1)=sum(shuju21{i,ind6});
    if shuju21{i,5}==0
        e1(i,2)=e1(i,1);
        s1(i,2)=s1(i,1);
        t1=t1+1;
    else
        e1(i,2)=shuju21{i,5};
        s1(i,2)=sum(shuju21{i,ind7});
    end
end
for i=1:1500
    e2(i,1)=shuju22{i,4};
    s2(i,1)=sum(shuju22{i,ind6});
    if shuju22{i,5}==0
        e2(i,2)=e2(i,1);
        s2(i,2)=s2(i,1);
        t2=t2+1;
    else
        e2(i,2)=shuju22{i,5};
        s2(i,2)=sum(shuju22{i,ind7});
    end
end

%% 图一，需要的去掉注释给其他的作图模块加注释
% subplot(2,1,1)
% scatter(e1(:,1),e1(:,2),'red','*')
% xlabel('初始极差')
% ylabel('复议后极差')
% title('附件21')
% grid on
% subplot(2,1,2)
% scatter(e2(:,1),e2(:,2),'red','*')
% xlabel('初始极差')
% ylabel('复议后极差')
% title('附件22')
% grid on
%% 图二，需要的去掉注释给其他的作图模块加注释
% subplot(3,1,1)
% scatter(e1(:,1),e1(:,2),'red','*')
% xlabel('初始极差')
% ylabel('复议后极差')
% title('附件21')
% grid on
% subplot(3,1,2)
% hist_del0(e1(:,1))
% xlabel('初始极差分布')
% subplot(3,1,3)
% hist_del0(e1(:,2))
% xlabel('复议极差分布')
%% 图三  需要的去掉注释给其他的作图模块加注释
% scatter(e2(:,1),e2(:,2),'red','*')
% hold on
% index=(s2(:,1)>s2(:,2));
% scatter(e2(index,1),e2(index,2),'green','*')
% xlabel('初始极差')
% ylabel('复议后极差')
% title('附件22')
% hold off
% grid on

%% 图四  需要的去掉注释给其他的作图模块加注释
% scatter3(e2(:,1),e2(:,2),s2(:,2)-s2(:,1),'red','*')
% hold on
% index=(s2(:,1)>s2(:,2));
% scatter3(e2(index,1),e2(index,2),s2(index,2)-s2(index,1),'green','*')
% xlabel('初始极差')
% ylabel('复议后极差')
% zlabel('复议前后分数差')
% title('附件22')
% hold off
% grid on


%% 图五  需要的去掉注释给其他的作图模块加注释
scatter3(e2(:,1),e2(:,1)-e2(:,2),s2(:,2)-s2(:,1),'red','*')
hold on
index=(s2(:,1)>s2(:,2));
scatter3(e2(index,1),e2(index,1)-e2(index,2),s2(index,2)-s2(index,1),'green','*')
xlabel('初始极差')
ylabel('初始极差-复议后极差')
zlabel('复议前后分数差')
title('附件22')
hold off
grid on


function []=hist_del0(data)
d=data(data~=0);
histogram(d)
histfit(d)
end

function m=mean_del0(data)
d=data(data~=0);
m=mean(d);
end

function m=std_del0(data)
d=data(data~=0);
m=std(d);
end
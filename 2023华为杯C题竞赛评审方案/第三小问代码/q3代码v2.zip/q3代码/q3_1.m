%% 数据预处理程序1
clc
clear
load("fujian.mat")
%% 表格数据说明
% 第二次评审 评审极差和复议后极差[4,5]
ind0=[4,5];
%            shuju21 240条二审
%            shuju22 1500条二审
% 第一次评审 专家编码列数[6,9,12,15,18]
%            原始分列数[7,10,13,16,19]
%            标准分列数[8,11,14,17,20]
ind1=[6,9,12,15,18];ind2=[7,10,13,16,19];ind3=[8,11,14,17,20];
% 第二次评审 专家编码列数[24,28,32]
%            原始分列数[25,29,33]
%            标准分列数[26,30,34]
%            复议分列数[27,31,35]
ind4=[24,28,32];ind5=[25,29,33];ind6=[26,30,34];ind7=[27,31,35];
%% 统计附件2.1/2.2成绩整体、极差变化
for i=1:240
    s1(i,1)=mean(shuju21{i,ind3});
    s1(i,2)=mean(shuju21{i,ind6});
    e1(i,1)=range(shuju21{i,ind3});
    e1(i,2)=range(shuju21{i,ind6});
end

for i=1:1500
    s2(i,1)=mean(shuju22{i,ind3});
    s2(i,2)=mean(shuju22{i,ind6});
    e2(i,1)=range(shuju22{i,ind3});
    e2(i,2)=range(shuju22{i,ind6});
end
%% 附件21作图1
% subplot(1,2,1)
% scatter(s1(:,1),s1(:,2),'red','*')
% xlabel('第一次均值')
% ylabel('第二次均值')
% title('附件21')
% grid on
% subplot(1,2,2)
% scatter(e1(:,1),e1(:,2),'red','*')
% xlabel('第一次极差')
% ylabel('第二次极差')
% title('附件21')
% grid on

%% 附件22作图2
% subplot(1,2,1)
% scatter(s2(:,1),s2(:,2),'red','*')
% xlabel('第一次均值')
% ylabel('第二次均值')
% title('附件22')
% grid on
% subplot(1,2,2)
% scatter(e2(:,1),e2(:,2),'red','*')
% xlabel('第一次极差')
% ylabel('第二次极差')
% title('附件22')
% grid on

% %% 附件21作图3
% subplot(1,2,1)
% index=s1(:,2)>s1(:,1);
% scatter(e1(:,1),e1(:,2),'red','*')
% hold on
% scatter(e1(index,1),e1(index,2),'green','*')
% xlabel('第一次极差')
% ylabel('第二次极差')
% title('附件21')
% hold off
% grid on
% %% 附件22作图3
% subplot(1,2,2)
% index=s2(:,2)>s2(:,1);
% scatter(e2(:,1),e2(:,2),'red','*')
% hold on
% scatter(e2(index,1),e2(index,2),'green','*')
% xlabel('第一次极差')
% ylabel('第二次极差')
% title('附件22')
% hold off
% grid on

%% 附件21作图4
% subplot(1,2,1)
% index=1:70;
% scatter(e1(:,1),e1(:,2),'red','*')
% hold on
% scatter(e1(index,1),e1(index,2),'green','*')
% xlabel('第一次极差')
% ylabel('第二次极差')
% title('附件21')
% hold off
% grid on
%% 附件22作图4
%subplot(1,2,2)
index=1:200;pindex=[201:1500];
scatter(e2(:,1),e2(:,2),'red','*')
hold on
plot(mean(e2(pindex,1))*ones(1,2),[0,60])
scatter(e2(index,1),e2(index,2),'green','*')
plot(mean(e2(index,1))*ones(1,2),[0,60])
xlabel('第一次极差')
ylabel('第二次极差')
title('附件22')
hold off
grid on

%% 附件21作图5
% subplot(2,2,1)
% hist_del0(s1(:,1))
% xlabel('第一次均值')
% title('附件21')
% subplot(2,2,2)
% hist_del0(s1(:,2))
% xlabel('第二次均值')
% title('附件21')
% subplot(2,2,3)
% hist_del0(e1(:,1))
% xlabel('第一次极差')
% title('附件21')
% subplot(2,2,4)
% hist_del0(e1(:,2))
% xlabel('第二次极差')
% title('附件21')


%% 附件22作图5
% subplot(2,2,1)
% hist_del0(s2(:,1))
% xlabel('第一次均值')
% title('附件22')
% subplot(2,2,2)
% hist_del0(s2(:,2))
% xlabel('第二次均值')
% title('附件22')
% subplot(2,2,3)
% hist_del0(e2(:,1))
% xlabel('第一次极差')
% title('附件22')
% subplot(2,2,4)
% hist_del0(e2(:,2))
% xlabel('第二次极差')
% title('附件22')

function []=hist_del0(data)
d=data(data~=0);
histogram(d)
histfit(d)
end

function m=mean_del0(data)
d=data(data~=0);
m=mean(d);
end

function m=std_del0(data)
d=data(data~=0);
m=std(d);
end
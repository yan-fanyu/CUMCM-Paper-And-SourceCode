%% 数据预处理程序1
clc
clear
load("shuju1.mat")
%% 对每一专家打分成绩进行处理
% 第一次评审 专家编码列数[6,9,12,15,18]
%            原始分列数[7,10,13,16,19]
%            标准分列数[8,11,14,17,20]
ind1=[6,9,12,15,18];ind2=[7,10,13,16,19];ind3=[8,11,14,17,20];
% 第二次评审 专家编码列数[24,28,32]
%            原始分列数[25,29,33]
%            标准分列数[26,30,34]
%            复议分列数[27,31,35]
ind4=[24,28,32];ind5=[25,29,33];ind6=[26,30,34];ind7=[27,31,35];
temp=[];
for i=ind1
temp=[temp;categories(table2array(shuju1(:,i)))];
end
dic1=unique(temp);
clear temp
%s->评分 e->极差 m->均值
s=zeros(length(dic1),2015);e=zeros(length(dic1),2015);m=zeros(length(dic1),2015); 
%_sd 为标准化后的数据
s_sd=zeros(length(dic1),2015);e_sd=zeros(length(dic1),2015);m_sd=zeros(length(dic1),2015);
for i=1:length(dic1)
    for j=ind2
        index=(dic1{i}==table2array(shuju1(:,j-1)));
        s(i,index)=table2array(shuju1(index,j))';
        %e(i,index)=range(table2array(shuju1(index,ind2)),2);
        m(i,index)=sum(table2array(shuju1(index,ind2)),2)'/5;
        s_sd(i,index)=table2array(shuju1(index,j+1))';
        e_sd(i,index)=table2array(shuju1(index,23))';
        m_sd(i,index)=sum(table2array(shuju1(index,ind3)),2)'/5;
        %注意！这里的数据会存在许多0值，是由于这里处理的时候将数据的排布与excel中的作品排序一一对应，这样会方便做一些别的处理
    end
end

% 画出对于某一评委而言其分数、极差、平均分分布图
% for i=1:4
%     for j=1:5
%         ind_temp=5*(i-1)+j;
%         subplot(4,5,ind_temp)
%         ind_temp=ind_temp+20; %这里20可以随便修改来看不同的图片
%         %hist_del0(s_sd(ind_temp,:))    %画出标准化评分
%         %hist_del0(s(ind_temp,:))  % 画出非标准化评分
%         hist_del0(m(ind_temp,:))  % 画出非标准化平均评分
%         %hist_del0(m_sd(ind_temp,:))  % 画出标准化平均评分
%         %hist_del0(e(ind_temp,:))  % 画出标准化极差
%         %hist_del0(e_sd(ind_temp,:))  % 画出标准化极差
%     end
% end
for i=1:97
    s_m(i)=mean_del0(s(i,:)); % 算出每个评委的平均打分
    s_s(i)=std_del0(s(i,:)); % 算出每个评委的标准差
end
%hist_del0(s_m)   % 画出每个评委的平均打分


function []=hist_del0(data)
d=data(data~=0);
histogram(d)
histfit(d)
end

function m=mean_del0(data)
d=data(data~=0);
m=mean(d);
end

function m=std_del0(data)
d=data(data~=0);
m=std(d);
end
%% 数据预处理程序3 用于评价、计算标准化模型
clc
clear
load("shuju1.mat")
load("zhuanjia_sm.mat")
%% 对每一专家打分成绩进行处理
% 第一次评审 专家编码列数[6,9,12,15,18]
%            原始分列数[7,10,13,16,19]
%            标准分列数[8,11,14,17,20]
ind1=[6,9,12,15,18];ind2=[7,10,13,16,19];ind3=[8,11,14,17,20];
% 第二次评审 专家编码列数[24,28,32]
%            原始分列数[25,29,33]
%            标准分列数[26,30,34]
%            复议分列数[27,31,35]
ind4=[24,28,32];ind5=[25,29,33];ind6=[26,30,34];ind7=[27,31,35];

%% 第一次评审数据提取和观察
for i=1:2015
    sc_1(i,:)=table2array(shuju1(i,ind2));
    sc_sd1(i,:)=table2array(shuju1(i,ind3));%_z表示作品，与q2_1内变量以示区分
end

%% 第二次评审数据提取和观察 共352条复试数据，其中27位一等奖，数据索引[1:23,25:28]（存在异常值）
ind_first=[1:23,25:28];
for i=1:352
    zhuanjia(i,:)=table2array(shuju1(i,ind4));
    sc_2(i,:)=table2array(shuju1(i,ind5));
    sc_sd2(i,:)=table2array(shuju1(i,ind6));
    sc_fy(i,:)=table2array(shuju1(i,ind7));
end
%% 自由发挥如何计算新的标准分，最后输出到sc_final中
m1=mean_del0([sc_1(:,1);sc_1(:,2);sc_1(:,3);sc_1(:,4);sc_1(:,5)]);
s1=std_del0([sc_1(:,1);sc_1(:,2);sc_1(:,3);sc_1(:,4);sc_1(:,5)]);
m2=mean_del0([sc_2(:,1);sc_2(:,2);sc_2(:,3)]);
s2=std_del0([sc_2(:,1);sc_2(:,2);sc_2(:,3)]);
for i=1:length(dic1)
    for j=ind2
        index=(dic1{i}==shuju1{:,j-1});
        s_temp1(i,index)=shuju1{index,j}';
    end
    for j=ind5
        index=(dic1{i}==shuju1{:,j-1});
        s_temp2(i,index)=shuju1{index,j}';
    end
end
for i=1:length(dic1)
    s_m2(i)=mean_del0(s_temp2(i,:)); % 算出每个评委的平均打分
    s_s2(i)=std_del0(s_temp2(i,:)); % 算出每个评委的标准差
end

alpha=0.21;beta=10;

%% 计算第二次评审
for i=ind_first
    for j=1:3
        index=find(dic1==zhuanjia(i,j));
        x_k(i,j)=50-alpha*(s_m2(index)-m2)+beta*(sc_2(i,j)-s_m2(index))/s_s2(index);
    end
end
%% 计算第一次评审
for i=ind_first
    in=0;
    for j=ind1
        in=in+1;
        index=find(dic1==table2array(shuju1(i,j)));
        sc_sd1(i,in)=50-alpha*(s_m(index)-m1)+beta*(sc_1(i,in)-s_m(index))/s_s(index); %需要注意的是每一轮对应的s_m和s_s
    end
end
%% 评审计分
sc_final=sum(x_k(ind_first,:),2)+mean(sc_sd1(ind_first,:),2); 

%% 计算sc_final的距离
[score,a_paiming]=sort(sc_final,1,"descend"); 
L_first=L(a_paiming,1)



function []=hist_del0(data)
d=data(data~=0);
histogram(d)
histfit(d)
end

function m=mean_del0(data)
d=data(data~=0);
m=mean(d,'all');
end

function m=std_del0(data)
d=data(data~=0);
m=std(d);
end

function L=L(index,mode)
if mode==1  %曼哈顿距离
L=sum(abs(index-[1:27]'));
elseif mode==2  %欧式距离
L=sqrt(sum((index-[1:27]').^2));
end
end
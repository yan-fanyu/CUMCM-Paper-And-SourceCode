%% 数据预处理程序2
clc
clear
load("shuju1.mat")
%% 对每一专家打分成绩进行处理
% 第一次评审 专家编码列数[6,9,12,15,18]
%            原始分列数[7,10,13,16,19]
%            标准分列数[8,11,14,17,20]
ind1=[6,9,12,15,18];ind2=[7,10,13,16,19];ind3=[8,11,14,17,20];
% 第二次评审 专家编码列数[24,28,32]
%            原始分列数[25,29,33]
%            标准分列数[26,30,34]
%            复议分列数[27,31,35]
ind4=[24,28,32];ind5=[25,29,33];ind6=[26,30,34];ind7=[27,31,35];
%第一次评审数据提取和观察
for i=1:2015
    e_z(i)=range(table2array(shuju1(i,ind2)),2);%_z表示作品，与q2_1内变量以示区分
    m_z(i)=sum(table2array(shuju1(i,ind2)),2)'/5;
    e_sd_z(i)=table2array(shuju1(i,23))';
    m_sd_z(i)=sum(table2array(shuju1(i,ind3)),2)'/5;
end
%% 均分和标准化均分的统计直方图
subplot(2,1,1)
hist_del0(m_z) %画出均分，观察其分布
subplot(2,1,2)
hist_del0(m_sd_z) %画出标准化均分，观察其分布
% 
% for i=1:4
%     for j=1:5
%         ind_temp=5*(i-1)+j;
%         subplot(4,5,ind_temp)
%         ind_temp=ind_temp+20; %这里20可以随便修改来看不同的图片
% %         hist_del0(table2array(shuju1(ind_temp,ind2)))    %画出非标准化评分
%         hist_del0(table2array(shuju1(ind_temp,ind3)))    %画出非标准化评分
%     end
% end


function []=hist_del0(data)
d=data(data~=0);
histogram(d)
histfit(d)
end
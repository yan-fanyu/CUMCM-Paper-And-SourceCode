%% 验证标准分审查假设是否成立
a1=27/2015;
c1=cv(a1)
a2=268/2015;
c2=cv(a2)
a3=373/2015;
c3=cv(a3)
c4=cv(a1+a2+a3)

function cv=cv(alpha)
cv=sqrt((1-alpha)*0.95*0.01/alpha);
end
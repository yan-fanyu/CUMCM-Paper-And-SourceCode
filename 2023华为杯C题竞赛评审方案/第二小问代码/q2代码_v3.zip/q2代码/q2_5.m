%% 数据预处理程序3 用于分析新的标准下数据的分布
clc
clear
load("shuju1.mat")
load("zhuanjia_sm.mat")
%% 对每一专家打分成绩进行处理
% 第一次评审 专家编码列数[6,9,12,15,18]
%            原始分列数[7,10,13,16,19]
%            标准分列数[8,11,14,17,20]
ind1=[6,9,12,15,18];ind2=[7,10,13,16,19];ind3=[8,11,14,17,20];
% 第二次评审 专家编码列数[24,28,32]
%            原始分列数[25,29,33]
%            标准分列数[26,30,34]
%            复议分列数[27,31,35]
ind4=[24,28,32];ind5=[25,29,33];ind6=[26,30,34];ind7=[27,31,35];

%% 第一次评审数据提取和观察
for i=1:2015
    sc_1(i,:)=table2array(shuju1(i,ind2));
    sc_sd1(i,:)=table2array(shuju1(i,ind3));%_z表示作品，与q2_1内变量以示区分
end

%% 第二次评审数据提取和观察 共352条复试数据，其中27位一等奖，数据索引[1:23,25:28]（存在异常值）
ind_first=[1:23,25:28];
for i=1:352
    zhuanjia(i,:)=table2array(shuju1(i,ind4));
    sc_2(i,:)=table2array(shuju1(i,ind5));
    sc_sd2(i,:)=table2array(shuju1(i,ind6));
    sc_fy(i,:)=table2array(shuju1(i,ind7));
end
%% 自由发挥如何计算新的标准分，最后输出到sc_final中
m1=mean_del0([sc_1(:,1);sc_1(:,2);sc_1(:,3);sc_1(:,4);sc_1(:,5)]);
s1=std_del0([sc_1(:,1);sc_1(:,2);sc_1(:,3);sc_1(:,4);sc_1(:,5)]);
m2=mean_del0([sc_2(:,1);sc_2(:,2);sc_2(:,3)]);
s2=std_del0([sc_2(:,1);sc_2(:,2);sc_2(:,3)]);
temp=[];
for i=ind4
temp=[temp;categories(table2array(shuju1(:,i)))];
end
dic2=unique(temp);
for i=1:length(dic2)
    for j=ind5
        index=(dic2{i}==table2array(shuju1(:,j-1)));
        s(i,index)=table2array(shuju1(index,j))';
        %注意！这里的数据会存在许多0值，是由于这里处理的时候将数据的排布与excel中的作品排序一一对应，这样会方便做一些别的处理
    end
end
for i=1:length(dic2)
    s_m2(i)=mean_del0(s(i,:)); % 算出每个评委的平均打分
    s_s2(i)=std_del0(s(i,:)); % 算出每个评委的标准差
end

alpha2=0;beta2=10;
alpha1=0;beta1=10;
%% 计算第二次评审
for i=ind_first
    for j=1:3
        index=find(dic2==zhuanjia(i,j));
        x_k(i,j)=50-alpha2*(s_m2(index)-m2)+beta2*(sc_2(i,j)-s_m2(index))/s_s2(index);
    end
end
%% 计算第一次评审
for i=1:2015
    in=0;
    for j=ind1
        in=in+1;
        index=find(dic1==table2array(shuju1(i,j)));
        sc_sd1(i,in)=50-alpha1*(s_m(index)-m1)+beta1*(sc_1(i,in)-s_m(index))/s_s(index); %需要注意的是每一轮对应的s_m和s_s
    end
end
for i=1:length(dic1)
    indj=0;
    for j=ind2
        indj=indj+1;
        index=(dic1{i}==table2array(shuju1(:,j-1)));
        s_sd(i,index)=sc_sd1(index,indj)';
        %注意！这里的数据会存在许多0值，是由于这里处理的时候将数据的排布与excel中的作品排序一一对应，这样会方便做一些别的处理
    end
end
% 画出对于某一评委而言其分数、极差、平均分分布图
% for i=1:4
%     for j=1:5
%         ind_temp=5*(i-1)+j;
%         subplot(4,5,ind_temp)
%         ind_temp=ind_temp+20; %这里20可以随便修改来看不同的图片
%         hist_del0(s_sd(ind_temp,:))    %画出标准化评分
%     end
% end
for i=1:4
    for j=1:5
        ind_temp=5*(i-1)+j;
        subplot(4,5,ind_temp)
        ind_temp=ind_temp+20; %这里20可以随便修改来看不同的图片
%         hist_del0(table2array(shuju1(ind_temp,ind2)))    %画出非标准化评分
        hist_del0(sc_sd2(ind_temp,:))    %画出非标准化评分
    end
end

function []=hist_del0(data)
d=data(data~=0);
histogram(d)
histfit(d)
end

function m=mean_del0(data)
d=data(data~=0);
m=mean(d,'all');
end

function m=std_del0(data)
d=data(data~=0);
m=std(d);
end

function L=L(index,mode)
if mode==1  %曼哈顿距离
L=sum(abs(index-[1:27]'));
elseif mode==2  %欧式距离
L=sqrt(sum((index-[1:27]').^2));
end
end